
package integradorjarvis;

import Ecxepciones.DispositivoExeption;
import Entidades.Armadura;
import Entidades.Dispositivo;

public class IntegradorJARVIS {

    public static void main(String[] args){
        Armadura JARVIS1 = new Armadura("Rojo", "Dorado", 100, 100, new Dispositivo(5), new Dispositivo(5), new Dispositivo(5), new Dispositivo(5), new Dispositivo(5),new Dispositivo(5));
        JARVIS1.mostrandoEstado();
        JARVIS1.informacionReactor();
        JARVIS1.volar(15);
        JARVIS1.correr(15);
        JARVIS1.caminar(15);
        JARVIS1.disparar(15);
    }
    
}
