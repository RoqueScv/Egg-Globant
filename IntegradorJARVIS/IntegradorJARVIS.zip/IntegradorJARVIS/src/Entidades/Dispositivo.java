package Entidades;

import Ecxepciones.DispositivoExeption;

public class Dispositivo {

    protected int consumoEnergia;
    public boolean daniado = false;
    public boolean destruido = false;

    public Dispositivo() {
    }

    public Dispositivo(int consumoEnergia) {
        this.consumoEnergia = consumoEnergia;
    }

    public boolean isDaniado() {
        return daniado;
    }

    public boolean isDaniadoCompleto() {
        return destruido;
    }

    public int usar(int intensidad, int tiempo) throws DispositivoExeption {
        if (!(daniado)) {
            int aux = (int) (Math.random() * 100) + 1;
            daniado = aux <= 30;
            return consumoEnergia * intensidad * tiempo;
        } else {
            try {
                if (daniado) {
                    throw new DispositivoExeption("--Dispositivo daniado--");
                }
            } catch (DispositivoExeption e) {
                revisandoDanios();
            }
            try {
                if (destruido) {
                    throw new DispositivoExeption("DISPOSITIVO DESTRUIDO");
                }
            } catch (DispositivoExeption e) {
            }
        }
        return consumoEnergia;
    }

    public void reparandoDanios() {
        int aux = (int) (Math.random() * 100) + 1;
        if (aux <= 40) {
            daniado = false;
        } else if (aux >= 40 && aux <= 70) {
            destruido = true;
        } else {
            daniado = true;
        }
    }

    public void revisandoDanios() {
        while (daniado && !(destruido)) {
            System.out.println("Intentando reparar");
            reparandoDanios();
            if (destruido) {
                System.out.println("El dispositivo se daño completamente");
            }
        }
        System.out.println("El dispositivo ha sido reparado");
    }
}
