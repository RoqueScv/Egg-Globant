
package Ecxepciones;

public class DispositivoExeption extends Exception {

    public DispositivoExeption() {
    }

    public DispositivoExeption(String msg) {
        super(msg);
    }
}
