
package ClsPersonaService;

import ClsPersona.Persona;
import java.util.Scanner;


public class PersonaService {
//    Metodo crearPersona(): el método crear persona, le pide los valores de los atributos
//al usuario y después se le asignan a sus respectivos atributos para llenar el objeto
//Persona. Además, comprueba que el sexo introducido sea correcto, es decir, H, M o
//O. Si no es correcto se deberá mostrar un mensaje
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    public Persona crearPersona()
    {
    Persona obj = new Persona();
        System.out.println("INGRESE SU NOMBRE:: ");
        obj.setNombre(leer.next());
        String s;
       do
       {
        System.out.println("INGRESE SU SEXO");
        s=leer.next();
       } while (!(s.equalsIgnoreCase("O")||s.equalsIgnoreCase("M")||s.equalsIgnoreCase("H")));
       obj.setSexo(s);
        
        System.out.println("INGRESE SU EDAD");
        obj.setEdad(leer.nextInt());
        System.out.println("INGRESE SU ALTURA");
        obj.setAltura(leer.nextDouble());
        System.out.println("INGRESE SU PESO");
        obj.setPeso(leer.nextDouble());
        
        return obj;
    }
//    Método calcularIMC(): calculara si la persona está en su peso ideal (peso en
//kg/(altura^2 en mt2)). Si esta fórmula da por resultado un valor menor que 20,
//significa que la persona está por debajo de su peso ideal y la función devuelve un -1.
//Si la fórmula da por resultado un número entre 20 y 25 (incluidos), significa que la
//persona está en su peso ideal y la función devuelve un 0. Finalmente, si el resultado
//de la fórmula es un valor mayor que 25 significa que la persona tiene sobrepeso, y la
//función devuelve un 1.
    
    public int calcularIMC(Persona obj)
    {
        double imc = obj.getIMC();
        if(imc<20)
        {
            return -1;
        }
       if(imc<25)
        {
            return 0;
        }
        return 1;
    }
//Método esMayorDeEdad(): indica si la persona es mayor de edad. La función
//devuelve un booleano.
public boolean esMayorDeEdad(Persona obj)
{
    int edad=obj.getEdad();
    
    if(edad<18)
    {
        return false;
    }
    return true;
}
public void mostrarResultadoIMC(String n,int resultado)
{
    switch (resultado) {
            case -1:
                System.out.println(n + " ESTA POR DEBAJO DE SU PESO");
                break;
            case 0:
                System.out.println(n + " ESTA EN SU PESO IDEAL");
                break;
            default:
                System.out.println(n +" TIENES SOBREPESO");
                break;
        }
}
}