
package Main;
//Realizar una clase llamada Persona que tenga los siguientes atributos: nombre, edad,
//sexo ('H' hombre, 'M' mujer, 'O' otro), peso y altura. Si el alumno desea añadir algún otro

import ClsPersona.Persona;
import ClsPersonaService.PersonaService;

//atributo, puede hacerlo. Los métodos que se implementarán son:

public class Dia6 {
//    Crear 4 objetos de tipo Persona con distintos valores, a continuación, llamaremos todos
//los métodos para cada objeto, deberá comprobar si la persona está en su peso ideal,
//tiene sobrepeso o está por debajo de su peso ideal e indicar para cada objeto si la
//persona es mayor de edad.
    public static void main(String[] args) {
        PersonaService pers1=new PersonaService();
        Persona obj1,obj2,obj3,obj4;
        
        obj1=pers1.crearPersona();
        obj2=pers1.crearPersona();
        obj3=pers1.crearPersona();
        obj4=pers1.crearPersona();
        
        int resultado = pers1.calcularIMC(obj1);
        pers1.mostrarResultadoIMC(obj1.getNombre(),resultado);
        resultado = pers1.calcularIMC(obj2);
        pers1.mostrarResultadoIMC(obj2.getNombre(),resultado);
        resultado = pers1.calcularIMC(obj3);
        pers1.mostrarResultadoIMC(obj3.getNombre(),resultado);
        resultado = pers1.calcularIMC(obj4);
        pers1.mostrarResultadoIMC(obj4.getNombre(),resultado);
        
       
    }
    
}
