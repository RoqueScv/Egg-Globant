
package ClsPersona;
//nombre, edad,
//sexo ('H' hombre, 'M' mujer, 'O' otro), peso y altura.

public class Persona {
    private String  nombre;
    private String sexo;
    private int edad;
    private double peso;
    private double altura;
    private double IMC;

    public Persona() {
    }

    public Persona(String nombre, String sexo, int edad, double peso, double altura) {
        this.nombre = nombre;
        this.sexo = sexo;
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
        this.IMC=peso/(altura*altura);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
        
    }

    public void setPeso(double peso) {
        this.peso = peso;
        this.IMC=peso/(altura*altura);
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
        this.IMC=peso/(altura*altura);
    }

    public double getIMC() {
        return IMC;
    }
        
    
}
