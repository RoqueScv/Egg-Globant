/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vehiculo;

/**
 *
 * @author dajos
 */
public class Vehiculo {
    public String marca;
    public String modelo;
    public int anho;
    public String tipo;

    public Vehiculo() {
    }

    public Vehiculo(String marca, String modelo, int anho, String tipo) {
        this.marca = marca;
        this.modelo = modelo;
        this.anho = anho;
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnho() {
        return anho;
    }

    public void setAnho(int anho) {
        this.anho = anho;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public int moverse(int segundo){
        int distancia=0;
        if (tipo.equalsIgnoreCase("automovil")){
            distancia=3*segundo;
        } else if  (tipo.equalsIgnoreCase("motocicleta")){
            distancia=2*segundo;
        } else if (tipo.equalsIgnoreCase("bicicleta")){
            distancia=segundo; 
        }else {System.out.println("Ingresaste un valor invalido");}
        
    
    return distancia;
    }
    
        public int frenar(){
            int distanciaf=0;
        if (tipo.equalsIgnoreCase("automovil")){
            distanciaf=2;
        } else if  (tipo.equalsIgnoreCase("motocicleta")){
            distanciaf=2;
        } else if (tipo.equalsIgnoreCase("bicicleta")){
            distanciaf=0; 
        }else {System.out.println("Ingresaste un valor invalido");
        
    }return distanciaf;}
}