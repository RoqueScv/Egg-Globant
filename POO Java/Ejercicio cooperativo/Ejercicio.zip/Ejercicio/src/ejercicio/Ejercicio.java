/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio;

import Vehiculo.Vehiculo;

/**
 *
 * @author dajos
 */
public class Ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vehiculo v1 = new Vehiculo("Ford", "Fiesta", 2020, "automovil");
        Vehiculo v2 = new Vehiculo("Ford", "Fiesta", 2020, "motocicleta");
        Vehiculo v3 = new Vehiculo("Ford", "Fiesta", 2020, "bicicleta");

        System.out.println("Vamos a avanzar 5 segundos");
        System.out.println(v1.moverse(5));
        System.out.println(v2.moverse(5));
        System.out.println(v3.moverse(5));

        System.out.println("Vamos a avanzar 10 segundos");
        System.out.println(v1.moverse(10));
        System.out.println(v2.moverse(10));
        System.out.println(v3.moverse(10));
        
        
        System.out.println("Vamos a avanzar 60 segundos");
        System.out.println(v1.moverse(60));
        System.out.println(v2.moverse(60));
        System.out.println(v3.moverse(60));
        
        
        System.out.println("Vamos a avanzar 300 segundos y frenar");
        System.out.println(v1.moverse(300)+v1.frenar());
        System.out.println(v2.moverse(300)+v2.frenar());
        System.out.println(v3.moverse(300)+v3.frenar());



    }

}
