/*
Se necesita una aplicación para una tienda en la cual queremos almacenar los distintos
productos que venderemos y el precio que tendrán. Además, se necesita que la
aplicación cuente con las funciones básicas.
Estas las realizaremos en el servicio. Como, 
introducir un elemento, 
modificar su precio,
eliminar un producto 
y mostrar los productos que tenemos con su precio 
(Utilizar
Hashmap). El HashMap tendrá de llave el nombre del producto y de valor el precio.
Realizar un menú para lograr todas las acciones previamente mencionadas.
 */
package Services;

import Entities.Producto;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Soso
 */
public class TiendaServices {
    
    Scanner read = new Scanner(System.in);
    
    HashMap<String,Double> productos = new HashMap();
    //<Nombre,Precio>
 
    public void crearProducto(){
   
        System.out.println("Nombre del producto:");
        String nombre = read.next();
        System.out.println("Precio del producto:");
        double precio= read.nextDouble();
        
        productos.put(nombre,precio);
        
        
    }
    
    public void agregarProducto(){
        
        String opcion;
        boolean flag=true;
        
        do{
        
            crearProducto();
            
            System.out.println("Desea agregar otro producto?:");
            opcion=read.next();
            if(opcion.equalsIgnoreCase("n")){
             flag=false;
            }
        
        
        }while(flag);
    
        imprimirMapa();
    }
    
    public void imprimirMapa(){
    
        for(Map.Entry<String,Double> item : productos.entrySet()){
        
        String key= item.getKey();
        Double value = item.getValue();
        
            System.out.println("Key:"+key+",Value:"+value);
        
        }
    
    
    }

    public void modificarPrecio() {

        System.out.println("Ingrese nombre del producto a modificar:");
        String nombre = read.next();
        double precio;

        for (Map.Entry<String, Double> item : productos.entrySet()) {
            String key = item.getKey();

            if (key.equalsIgnoreCase(nombre)) {
                System.out.println("Ingrese precio nuevo:");
                precio = read.nextDouble();

                productos.put(nombre, precio);
                break;

            }

        }
        imprimirMapa();
    }
    
    public void eliminarProducto(){
        
     System.out.println("Ingrese nombre del producto a eliminar:");
        String nombre = read.next();
       

        for (Map.Entry<String, Double> item : productos.entrySet()) {
            String key = item.getKey();

            if (key.equalsIgnoreCase(nombre)) {
                productos.remove(nombre);
                break;

            }

        }
        imprimirMapa();
    
    
    
    }

    public void menu(){
        agregarProducto();
       // modificarPrecio();
        eliminarProducto();
    
    }
            
}
