package Services;

import Entidades.Producto;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ProductoServices {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    HashMap <String, Producto> productos = new HashMap();

    public void crearProducto() {

        do {

            Producto p1 = new Producto();

            System.out.println("Ingrese el nombre del producto");
            p1.setNombre(leer.next());

            System.out.println("Ingrese el precio del producto");
            p1.setPrecio(leer.nextDouble());
            
            productos.put(p1.getNombre(), p1);

            System.out.println("Desea ingresar otro producto?");
          
        } while (!(leer.next().equalsIgnoreCase("n")));

    }
    
    public void mostrar(){
        for (Map.Entry <String, Producto> entry : productos.entrySet()) {
            
            System.out.println("Producto " + entry.getKey());
            System.out.println("Precio " + entry.getValue());
            
        }
    }
    
    public void remover(){
        
        System.out.println("Que producto desea eliminar?");
        String productoEliminar = leer.next();

        if(productos.containsKey(productoEliminar)){
             productos.remove(productoEliminar);
             System.out.println("El producto ha sido eliminado");
        } else {
            System.out.println("No se ha encontrado el producto que desea eliminar");
        }
    }
    
    public void cambiarPrecio(){
        
        System.out.println("A que producto desea cambiarle el precio?");
        String productoCambiar = leer.next();
        
        Producto p1 = productos.get(productoCambiar);
        boolean flag = productos.containsKey(productoCambiar);
        
        if(flag){
            
            System.out.println("Ingrese el nuevo precio");
            Double nuevoPrecio = leer.nextDouble();
            p1.setPrecio(nuevoPrecio);
            
            productos.put(productoCambiar,p1 );
            
        } else {
            System.out.println("No se ha encontrado el producto al que desea cambiarle el precio");
        }
    }
    
    public void menu(){
        
        int op;
        
        do{
        System.out.println("Ingrese la opcion que desea realizar");
        System.out.println("1. Agregar producto");
        System.out.println("2. Mostrar productos");
        System.out.println("3. Remover producto");
        System.out.println("4. Cambiar precio");
        System.out.println("5. Salir");
        op = leer.nextInt();
        
            switch(op){
                case 1:
                    crearProducto();
                    break;
                case 2:
                    mostrar();
                    break;
                case 3:
                    remover();
                    break;
                case 4:
                    cambiarPrecio();
                    break;
                case 5:
                    break;
                
            }
        } while (op!=5);
    }
    
}
