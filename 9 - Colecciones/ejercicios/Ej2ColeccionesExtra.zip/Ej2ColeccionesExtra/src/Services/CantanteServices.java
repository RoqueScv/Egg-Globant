package Services;

import Entidades.Cantante;
import java.util.ArrayList;
import java.util.Scanner;

public class CantanteServices {

    ArrayList<Cantante> cantantes = new ArrayList<>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearLista() {
        do {
            Cantante c1 = new Cantante();

            System.out.println("Ingrese el nombre del cantante");
            c1.setNombre(leer.next());
            System.out.println("Ingrese su disco mas vendido");
            c1.setDiscoMasVendido(leer.next());
            
            cantantes.add(c1);
            
            System.out.println("Desea seguir agregando cantantes? s/n");

        } while (!(leer.next().equals("n")));
    }
    
    public void mostrar(){
        System.out.println(cantantes);
    }
    
    public void eliminarCantante(){
        System.out.println("A que cantante desea eliminar?");
        String cantanteEliminar = leer.next();
        
        for (Cantante cantante : cantantes) {
            if(cantante.getNombre().equals(cantanteEliminar)){
                cantantes.remove(cantante);
            }
        }
        
    }

}
