package Services;

import java.util.ArrayList;
import java.util.Scanner;

public class NumeroServices {

    ArrayList<Integer> numeros = new ArrayList<>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearArray() {
        Integer num;
        System.out.println("Ingrese un numero que desea agregar a la lista. Exceptuando al -99");
        num = leer.nextInt();

        while (num != -99) {
            numeros.add(num);
            System.out.println("Ingrese un numero que desea agregar a la lista. Exceptuando al -99");
            num = leer.nextInt();
        }
    }

    public void mostrar() {
        System.out.println(numeros);

//        Mostrar con un forEach, lambda, sin toString
//        numeros.forEach(numero->System.out.println(numero));
    }

    public Integer suma() {
        Integer suma = 0;

        for (Integer numero : numeros) {
            suma += numero;
        }

        return suma;

    }

    public double promedio() {
//        uso el retorno de la funcion suma y hago los sout en el main
        if (numeros.size() > 0) {
            return suma() / numeros.size();
        } else {
            return 0;
        }
    }
}
