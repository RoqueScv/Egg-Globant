/*
Diseñar un programa que lea una serie de valores numéricos enteros desde el teclado y
los guarde en un ArrayList de tipo Integer. La lectura de números termina cuando se
introduzca el valor -99. Este valor no se guarda en el ArrayList. A continuación, el
programa mostrará por pantalla el número de valores que se han leído, su suma y su
media (promedio). 
 */
package ej1coleccionesextra;

import Services.NumeroServices;

public class Ej1ColeccionesExtra {

    public static void main(String[] args) {
        NumeroServices n1 = new NumeroServices();
        
        n1.crearArray();
        n1.mostrar();
        System.out.println("La suma de todos los numeros ingresados es " + n1.suma());
        System.out.println("El promedio de todos los numeros es " + n1.promedio());
    }

}
