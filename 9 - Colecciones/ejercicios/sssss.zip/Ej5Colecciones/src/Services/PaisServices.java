package Services;

import Entidades.Pais;
import Utilidades.Comparators;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class PaisServices {

    HashSet<Pais> paises = new HashSet<>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearPais() {

        boolean op = true;

        do {
            Pais p1 = new Pais();
            System.out.println("Ingrese el nombre del pais");
            p1.setNombre(leer.next());

            System.out.println("Desea ingresar otro pais? s/n");
            if (leer.next().equalsIgnoreCase("n")) {
                op = false;
            }
            paises.add(p1);

        } while (op);
    }
    
    public void mostrar(){
        System.out.println(paises);
    }
    
    public void ordenar(){
        ArrayList <Pais> listaPaises = new ArrayList <>(paises);
        listaPaises.sort(Comparators.ordenar);
        System.out.println("--ORDENADOS--");
        System.out.println(listaPaises);
    }
    
    public void remover(){
        boolean flag = true;
        String paisBorrar;
        
        System.out.println("Ingrese el pais que desea borrar");
        paisBorrar = leer.next();
        Iterator <Pais> it = paises.iterator();
        while (it.hasNext()){
            if (it.next().getNombre().equals(paisBorrar)){
                it.remove();
                System.out.println("El pais fue borrado");
                flag = false;
                break;
            }
        }
        if (flag) {
            System.out.println("No se encontro el pais");
        }
        
        System.out.println("CON EL PAIS BORRADO");
        System.out.println(paises);
    }
}
