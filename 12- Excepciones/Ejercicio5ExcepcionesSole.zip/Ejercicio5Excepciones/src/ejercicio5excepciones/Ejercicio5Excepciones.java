/*
Escribir un programa en Java que juegue con el usuario a adivinar un número. La computadora
debe generar un número aleatorio entre 1 y 500, y el usuario tiene que intentar adivinarlo. Para
ello, cada vez que el usuario introduce un valor, la computadora debe decirle al usuario si el
número que tiene que adivinar es mayor o menor que el que ha introducido el usuario. Cuando
consiga adivinarlo, debe indicárselo e imprimir en pantalla el número de veces que el usuario
ha intentado adivinar el número. Si el usuario introduce algo que no es un número, se debe
controlar esa excepción e indicarlo por pantalla. En este último caso también se debe contar el
carácter fallido como un intento.
 */
package ejercicio5excepciones;

import java.util.Scanner;

/**
 *
 * @author Soso
 */
public class Ejercicio5Excepciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");

        int num = (int) ((Math.random() * 500) + 1);

        //System.out.println(num);

        int intentos = 0;

        int numInput = 0;

        while (num != numInput) {

           try{
            System.out.println("Ingresá un numero vieja:");
            numInput = read.nextInt();
            
            if(numInput>num){
                System.out.println("El numero a adivinar es menor al que ingresaste");
            }else if(numInput<num){
                System.out.println("El numero a adivinar es mayor al que ingresaste");
            }
           
           }catch(Exception e){
           
               System.out.println("Cualquier cosa ingresaste");
               read.nextLine();
           }finally{
               intentos++;
           }

        }
        
        System.out.println("Muy bien, adivinaste a los " +intentos+ " intentos loco");

        
    }

}
